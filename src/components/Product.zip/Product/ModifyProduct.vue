<template lang="">
    <div>
        asd
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>